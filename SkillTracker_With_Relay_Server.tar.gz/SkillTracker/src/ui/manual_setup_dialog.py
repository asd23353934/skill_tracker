"""
手動設定指引對話框
當 UPnP 自動設定失敗時顯示
"""

import tkinter as tk
from tkinter import messagebox, scrolledtext
from src.ui.components import Colors, Fonts, RoundedButton
from src.ui.dialogs import BaseDialog


class ManualSetupDialog(BaseDialog):
    """手動設定指引對話框"""
    
    def __init__(self, parent, external_ip, local_ip):
        """初始化對話框
        
        Args:
            parent: 父視窗
            external_ip: 外網 IP
            local_ip: 內網 IP
        """
        self.external_ip = external_ip
        self.local_ip = local_ip
        super().__init__(parent, "手動設定端口轉發", 700, 600)
        self._create_ui()
    
    def _create_ui(self):
        """創建 UI"""
        # 標題
        title_frame = tk.Frame(self.dialog, bg=Colors.BG_MEDIUM)
        title_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(
            title_frame,
            text="⚠️ UPnP 自動設定失敗",
            bg=Colors.BG_MEDIUM,
            fg=Colors.ACCENT_YELLOW,
            font=Fonts.TITLE_SMALL
        ).pack()
        
        tk.Label(
            title_frame,
            text="請手動設定路由器端口轉發",
            bg=Colors.BG_MEDIUM,
            fg=Colors.TEXT_SECONDARY,
            font=Fonts.BODY_SMALL
        ).pack()
        
        # 說明文字區域
        text_frame = tk.Frame(self.dialog, bg=Colors.BG_MEDIUM)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # 使用 ScrolledText
        self.text_area = scrolledtext.ScrolledText(
            text_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            bg=Colors.BG_DARK,
            fg=Colors.TEXT_PRIMARY,
            relief=tk.FLAT,
            padx=15,
            pady=15
        )
        self.text_area.pack(fill=tk.BOTH, expand=True)
        
        # 插入說明文字
        guide_text = self._generate_guide_text()
        self.text_area.insert('1.0', guide_text)
        self.text_area.config(state=tk.DISABLED)  # 只讀
        
        # 按鈕區域
        btn_frame = tk.Frame(self.dialog, bg=Colors.BG_MEDIUM)
        btn_frame.pack(pady=15)
        
        RoundedButton(
            btn_frame,
            "📋 複製內網 IP",
            lambda: self._copy_to_clipboard(self.local_ip),
            Colors.ACCENT_BLUE,
            width=140,
            height=35
        ).pack(side=tk.LEFT, padx=5)
        
        RoundedButton(
            btn_frame,
            "🌐 複製外網 IP",
            lambda: self._copy_to_clipboard(self.external_ip),
            Colors.ACCENT_PURPLE,
            width=140,
            height=35
        ).pack(side=tk.LEFT, padx=5)
        
        RoundedButton(
            btn_frame,
            "✓ 我知道了",
            self.close,
            Colors.ACCENT_GREEN,
            width=140,
            height=35
        ).pack(side=tk.LEFT, padx=5)
    
    def _generate_guide_text(self):
        """生成指引文字"""
        return f"""
╔══════════════════════════════════════════════════════════╗
║             手動設定路由器端口轉發指引                    ║
╚══════════════════════════════════════════════════════════╝

由於 UPnP 自動設定失敗，您需要手動設定路由器才能讓不同網路
的玩家加入您的房間。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【您的網路信息】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

外網 IP: {self.external_ip}
內網 IP: {self.local_ip}
端口:    9999


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【設定步驟】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

步驟 1：登入路由器管理頁面
────────────────────────────────────────
  1. 打開瀏覽器
  2. 輸入路由器 IP（通常是以下之一）:
     • http://192.168.1.1
     • http://192.168.0.1
     • http://10.0.0.1
  3. 輸入管理員帳號密碼（通常在路由器背面標籤）


步驟 2：找到端口轉發設定
────────────────────────────────────────
  不同品牌路由器名稱不同，可能是：
  • 「端口轉發」(Port Forwarding)
  • 「虛擬伺服器」(Virtual Server)
  • 「NAT 設定」(NAT Settings)
  • 「應用程式及遊戲」(Applications & Gaming)


步驟 3：新增端口轉發規則
────────────────────────────────────────
  請按照以下信息填寫：

  服務名稱:  SkillTracker
  外部端口:  9999
  內部 IP:   {self.local_ip}  ← 點擊按鈕複製
  內部端口:  9999
  協定:      TCP
  狀態:      啟用


步驟 4：開放 Windows 防火牆
────────────────────────────────────────
  1. 控制台 → 系統及安全性 → Windows Defender 防火牆
  2. 左側點擊「進階設定」
  3. 左側點擊「輸入規則」→ 右側點擊「新增規則」
  4. 選擇「連接埠」→ 下一步
  5. 選擇「TCP」→ 特定本機連接埠: 9999 → 下一步
  6. 選擇「允許連線」→ 下一步
  7. 全部勾選 → 下一步
  8. 名稱: SkillTracker → 完成


步驟 5：測試端口是否開放
────────────────────────────────────────
  1. 訪問: http://www.yougetsignal.com/tools/open-ports/
  2. 輸入您的外網 IP: {self.external_ip}
  3. 輸入端口: 9999
  4. 點擊 Check
  5. 如果顯示 "Open" → 設定成功 ✅
     如果顯示 "Closed" → 請檢查上述步驟


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【常見問題】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Q: 找不到路由器管理頁面？
A: 1. 確認電腦已連線到路由器
   2. 打開命令提示字元輸入: ipconfig
   3. 查看「預設閘道」的 IP

Q: 忘記路由器密碼？
A: 1. 查看路由器背面標籤
   2. 或重設路由器（按住 Reset 鈕 10 秒）

Q: 設定後仍然無法連線？
A: 1. 檢查防火牆是否允許
   2. 檢查防毒軟體是否阻擋
   3. 確認內網 IP 沒有改變（重啟電腦/路由器後可能改變）
   4. 確認外網 IP 沒有改變（有些ISP會定期更換）


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【替代方案】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

如果您不想手動設定，可以：

方案 1: 只在同一 WiFi 使用
   • 最簡單，無需設定
   • 適合同地點的朋友

方案 2: 使用 VPN 軟體
   • Hamachi、ZeroTier、Radmin VPN
   • 安裝後視為同一網路

方案 3: 使用遠端桌面
   • Discord 螢幕分享、TeamViewer
   • 簡單但畫質差、延遲高


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

詳細圖文教學請參考: NETWORK_SETUP.md

"""
    
    def _copy_to_clipboard(self, text):
        """複製到剪貼簿"""
        self.dialog.clipboard_clear()
        self.dialog.clipboard_append(text)
        messagebox.showinfo(
            "已複製",
            f"已複製到剪貼簿:\n{text}",
            parent=self.dialog
        )


if __name__ == '__main__':
    # 測試
    root = tk.Tk()
    root.withdraw()
    
    dialog = ManualSetupDialog(root, "123.45.67.89", "192.168.1.100")
    dialog.show()
    
    root.destroy()
