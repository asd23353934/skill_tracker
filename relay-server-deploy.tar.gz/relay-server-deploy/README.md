# 🌐 技能追蹤器中繼伺服器

這是一個獨立的中繼伺服器，用於讓技能追蹤器實現跨網路連線。

---

## 🚀 快速部署（3 種方式）

### 方法 1: Railway.app（最推薦）⭐⭐⭐⭐⭐

**為什麼推薦:**
- ✅ 完全免費（每月 500 小時）
- ✅ 永久運行（不休眠）
- ✅ 自動 HTTPS
- ✅ 3 分鐘部署完成

**部署步驟:**

1. **註冊 Railway**
   ```
   訪問: https://railway.app/
   使用 GitHub 帳號登入
   ```

2. **創建新專案**
   ```
   Dashboard → New Project → Deploy from GitHub repo
   或者: New Project → Empty Project
   ```

3. **上傳代碼**

   **方法 A: 從 GitHub（推薦）**
   ```bash
   # 1. 創建 GitHub repo
   # 2. 上傳這個資料夾的所有文件
   # 3. Railway → Deploy from GitHub → 選擇 repo
   ```

   **方法 B: 使用 CLI**
   ```bash
   # 安裝 Railway CLI
   npm i -g @railway/cli
   
   # 登入
   railway login
   
   # 在這個資料夾執行
   cd relay-server-deploy
   railway init
   railway up
   ```

4. **獲取網址**
   ```
   Settings → Generate Domain
   例如: https://skilltracker-relay.up.railway.app
   ```

5. **完成！**
   ```
   伺服器會自動啟動
   地址和端口會自動配置
   ```

---

### 方法 2: Render.com ⭐⭐⭐⭐☆

**部署步驟:**

1. **註冊 Render**
   ```
   訪問: https://render.com/
   ```

2. **創建 Web Service**
   ```
   New → Web Service
   ```

3. **連接 GitHub 或直接上傳**
   ```
   Connect GitHub repo
   或使用 Blueprint（會自動讀取 render.yaml）
   ```

4. **設定（如果手動設定）**
   ```
   Name: skilltracker-relay
   Environment: Python 3
   Build Command: (留空)
   Start Command: python relay_server.py --host 0.0.0.0 --port $PORT
   ```

5. **部署**
   ```
   點擊 Create Web Service
   等待部署完成
   ```

6. **獲取網址**
   ```
   例如: https://skilltracker-relay.onrender.com
   ```

**注意**: Render 免費版會在 15 分鐘無活動後休眠。

---

### 方法 3: 本地電腦 + ngrok（測試用）⭐⭐⭐☆☆

**適合場景:**
- 快速測試
- 臨時使用
- 不想註冊帳號

**步驟:**

1. **本地運行伺服器**
   ```bash
   python relay_server.py --host 127.0.0.1 --port 8888
   ```

2. **下載 ngrok**
   ```
   訪問: https://ngrok.com/download
   解壓縮
   ```

3. **運行 ngrok**
   ```bash
   # Windows
   ngrok.exe tcp 8888
   
   # Mac/Linux
   ./ngrok tcp 8888
   ```

4. **獲取公開地址**
   ```
   會顯示類似:
   Forwarding: tcp://0.tcp.ngrok.io:12345 -> localhost:8888
   
   使用: 0.tcp.ngrok.io:12345
   ```

**缺點**: 
- 臨時地址（每次重啟會變）
- 需要保持電腦開機
- 免費版有連線限制

---

## 📝 部署後配置客戶端

部署完成後，需要在技能追蹤器客戶端配置伺服器地址。

**修改 `src/core/relay_client.py`:**

```python
RELAY_SERVERS = [
    # 你的 Railway 伺服器（HTTPS，端口 443）
    ('skilltracker-relay.up.railway.app', 443),
    
    # 或你的 Render 伺服器
    ('skilltracker-relay.onrender.com', 443),
    
    # 或你的 ngrok 地址（注意：每次都會變）
    ('0.tcp.ngrok.io', 12345),
    
    # 本地測試
    ('127.0.0.1', 8888),
]
```

**注意**: 
- Railway 和 Render 會自動提供 HTTPS，使用端口 443
- ngrok 使用 TCP，端口是動態分配的
- 本地測試使用 8888

---

## 🧪 測試伺服器

**方法 1: 使用 telnet（簡單）**

```bash
# Windows
telnet your-server.railway.app 443

# Mac/Linux  
telnet your-server.railway.app 443
```

如果連線成功，伺服器就正常運行。

**方法 2: 使用 Python 腳本**

```python
import socket
import json

# 連線
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect(('your-server.railway.app', 443))

# 發送測試訊息
msg = json.dumps({
    'type': 'init',
    'room_code': 'TEST123',
    'player_name': 'TestPlayer'
}) + '\n'

sock.send(msg.encode())

# 接收回應
response = sock.recv(1024).decode()
print(response)
# 應該看到: {"status": "ok", ...}
```

---

## 📊 成本和限制

| 平台 | 免費額度 | 限制 | 休眠 |
|------|---------|------|------|
| Railway | 500 小時/月 | $5 額度 | ❌ 否 |
| Render | 無限制 | 512MB RAM | ✅ 15分鐘 |
| ngrok | 1 連線 | 40 連線/分鐘 | N/A |

**推薦**: Railway（不會休眠，最穩定）

---

## 🔧 進階設定

### 添加日誌

修改 `relay_server.py`，添加日誌記錄：

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)
```

### 限制房間數量

```python
MAX_ROOMS = 100

def _join_room(self, room_code, ...):
    if len(self.server.relay_rooms) >= MAX_ROOMS:
        raise Exception("伺服器已滿")
```

### 添加認證

```python
API_KEY = "your-secret-key"

def _verify_api_key(self, key):
    return key == API_KEY
```

---

## 🆘 疑難排解

### 問題 1: 部署後無法連線

**檢查清單:**
```
□ 伺服器是否正在運行？
□ 防火牆是否開放端口？
□ 客戶端地址是否正確？
□ 端口是否正確？（Railway/Render 用 443）
```

### 問題 2: Railway/Render 一直重啟

**原因**: 可能是端口綁定問題

**解決**:
```python
# 確保使用環境變數的端口
import os
port = int(os.environ.get('PORT', 8888))
```

### 問題 3: ngrok 地址一直變

**解決**: 升級到 ngrok 付費版（$8/月）獲得固定地址
**或**: 使用 Railway/Render（免費且地址固定）

---

## 📞 支援

遇到問題？

1. 檢查伺服器日誌
2. 查看客戶端控制台輸出
3. 測試網路連線
4. 參考主專案的 `DEPLOY_FIX.md`

---

## 📁 文件說明

- `relay_server.py` - 伺服器主程式
- `requirements.txt` - Python 依賴（空的，不需要額外套件）
- `render.yaml` - Render.com 自動配置
- `railway.json` - Railway.app 配置
- `Procfile` - Heroku 配置
- `README.md` - 本文件

---

**最後更新**: 2025-01-01
**作者**: Claude
**授權**: MIT

---

🎉 **祝部署順利！**
